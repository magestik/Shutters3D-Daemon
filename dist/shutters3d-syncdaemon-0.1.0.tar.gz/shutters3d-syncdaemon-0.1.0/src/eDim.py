#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys, os, time

# Here we have to put all the code for controlling eDimensionnal Glasses in future release ...

sys.exit()
